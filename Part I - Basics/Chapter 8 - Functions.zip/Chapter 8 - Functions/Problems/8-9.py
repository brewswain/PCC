magicians = ['harry', 'leanansidhe', 'dresden', 'harkle']


def show_magicians():
    print("May I present, the world's greatest magicians!")
    for magician in magicians:
        print(magician.title())


show_magicians()
