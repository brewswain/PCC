def favourite_book(title):
    """Accepts a parameter + argument to print a message."""
    print("One of my favourite books is " + title.title() + ".")


favourite_book('warbreaker')
