def display_message():
    """Describe this chapter's goal."""
    print("I'm learning to properly use functions D:")


display_message()
