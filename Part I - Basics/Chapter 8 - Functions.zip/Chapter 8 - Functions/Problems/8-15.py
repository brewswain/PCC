import printing_functions as models

unprinted_designs = ['iphone case', 'robot pendant', 'dodecahedron']
completed_models = []

models.print_models(unprinted_designs, completed_models)
models.show_completed_models(completed_models)
